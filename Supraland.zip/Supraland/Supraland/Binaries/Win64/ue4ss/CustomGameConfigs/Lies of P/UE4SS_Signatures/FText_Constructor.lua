function Register()
    return "48 89 5C 24 ?? 48 89 6C 24 ?? 56 57 41 54 41 56 41 57 48 83 EC ?? 45 33 E4 48 8B F1 48 8B 0D"
end

function OnMatchFound(MatchAddress)
    return MatchAddress
end