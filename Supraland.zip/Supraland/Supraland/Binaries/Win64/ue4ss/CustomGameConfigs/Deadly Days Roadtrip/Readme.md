Those configs were created for Early Access version v0.14.7

- The only change to `UE4SS-settings.ini` is adding an `EngineVersionOverride` for UE 5.6 (the game uses 5.6.1)
- `FText_Constructor.lua` points to `FText::FromString(FString&&)`