function Register()
    return "4C 8B DC 55 53 41 56 49 8D AB ?? ?? ?? ?? 48 81 EC C0 02 00 00"
end

function OnMatchFound(MatchAddress)
    return MatchAddress
end