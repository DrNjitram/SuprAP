function Register()
    return "48 89 5C 24 10 48 89 6C 24 18 48 89 74 24 20 57 48 83 EC 20 8B 01"
end

function OnMatchFound(MatchAddress)
    return MatchAddress
end