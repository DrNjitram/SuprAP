function Register()
    return "48 89 5C 24 08 48 89 74 24 20 57 B8 70 00 00 00 E8 ?? ?? ?? ?? 48 2B E0 48 8B ?? ?? ?? ?? ?? 48 33 C4 48 89 44 24 60 48 8B 42 20 49 8B F0 48 8B DA EB 15"
    -- return "40 55 53 56 57 41 54 41 55 41 56 41 57 B8 E8 00 00 00"
end

function OnMatchFound(matchAddress)

    return matchAddress
end