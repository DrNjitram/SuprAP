function Register()
    return "48 8B C4 56 57 48 83 EC 68 48 89 58 18 48 8B F9"
end

function OnMatchFound(MatchAddress)
    return MatchAddress
end
