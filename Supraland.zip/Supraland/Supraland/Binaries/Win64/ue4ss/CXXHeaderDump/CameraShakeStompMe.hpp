#ifndef UE4SS_SDK_CameraShakeStompMe_HPP
#define UE4SS_SDK_CameraShakeStompMe_HPP

class UCameraShakeStompMe_C : public UMatineeCameraShake
{
}; // Size: 0x180

#endif
