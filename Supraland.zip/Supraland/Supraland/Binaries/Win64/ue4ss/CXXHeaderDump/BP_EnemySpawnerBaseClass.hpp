#ifndef UE4SS_SDK_BP_EnemySpawnerBaseClass_HPP
#define UE4SS_SDK_BP_EnemySpawnerBaseClass_HPP

class ABP_EnemySpawnerBaseClass_C : public AActor
{
    class USceneComponent* DefaultSceneRoot;                                          // 0x0220 (size: 0x8)
    bool bEnemySpawnerDestroyed;                                                      // 0x0228 (size: 0x1)
    int32 spawnerTier;                                                                // 0x022C (size: 0x4)

}; // Size: 0x230

#endif
