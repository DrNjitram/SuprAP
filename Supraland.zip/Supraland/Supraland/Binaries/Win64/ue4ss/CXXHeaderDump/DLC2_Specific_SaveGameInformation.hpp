#ifndef UE4SS_SDK_DLC2_Specific_SaveGameInformation_HPP
#define UE4SS_SDK_DLC2_Specific_SaveGameInformation_HPP

struct FDLC2_Specific_SaveGameInformation
{
    int32 Area4_WaterLevel_3_B1C24C76461DB52CC2C179A61132E669;                        // 0x0000 (size: 0x4)
    class AActor* Area4_WaterManager_8_37388C484C7FFA20651342BE16F349F5;              // 0x0008 (size: 0x8)
    bool TrackingHobo_10_8FFE05DB448B4A91F14E188953C44123;                            // 0x0010 (size: 0x1)

}; // Size: 0x11

#endif
