#ifndef UE4SS_SDK_Cupboard_Preset_07_HPP
#define UE4SS_SDK_Cupboard_Preset_07_HPP

class ACupboard_Preset_07_C : public AStaticMeshActor
{
    class UStaticMeshComponent* Cupboard_Preset_07;                                   // 0x0230 (size: 0x8)

}; // Size: 0x238

#endif
