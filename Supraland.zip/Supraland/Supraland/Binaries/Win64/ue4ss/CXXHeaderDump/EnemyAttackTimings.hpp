#ifndef UE4SS_SDK_EnemyAttackTimings_HPP
#define UE4SS_SDK_EnemyAttackTimings_HPP

struct FEnemyAttackTimings
{
    float StartDelay_5_779DA2AF4A07DACC9214BA9ACFA2E9B0;                              // 0x0000 (size: 0x4)
    float EndDelay_7_48979E1E4B06A4F7F9EC4B810CE35ABF;                                // 0x0004 (size: 0x4)
    float PlayRate_9_6F9DCFEB4019CC57E0E5D1ACD3981E8B;                                // 0x0008 (size: 0x4)

}; // Size: 0xC

#endif
