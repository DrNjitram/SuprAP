#ifndef UE4SS_SDK_AvfMediaFactory_HPP
#define UE4SS_SDK_AvfMediaFactory_HPP

class UAvfMediaSettings : public UObject
{
    bool NativeAudioOut;                                                              // 0x0028 (size: 0x1)

}; // Size: 0x30

#endif
