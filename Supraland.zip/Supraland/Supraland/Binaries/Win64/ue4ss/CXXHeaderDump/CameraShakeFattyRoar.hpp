#ifndef UE4SS_SDK_CameraShakeFattyRoar_HPP
#define UE4SS_SDK_CameraShakeFattyRoar_HPP

class UCameraShakeFattyRoar_C : public UMatineeCameraShake
{
}; // Size: 0x180

#endif
