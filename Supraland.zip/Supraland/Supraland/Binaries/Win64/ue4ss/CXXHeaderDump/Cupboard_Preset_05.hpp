#ifndef UE4SS_SDK_Cupboard_Preset_05_HPP
#define UE4SS_SDK_Cupboard_Preset_05_HPP

class ACupboard_Preset_05_C : public AStaticMeshActor
{
    class UStaticMeshComponent* Cupboard_Preset_05;                                   // 0x0230 (size: 0x8)

}; // Size: 0x238

#endif
