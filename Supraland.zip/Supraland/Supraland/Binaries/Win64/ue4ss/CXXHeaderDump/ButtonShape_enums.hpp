namespace ButtonShape {
    enum Type {
        NewEnumerator0 = 0,
        NewEnumerator2 = 1,
        NewEnumerator3 = 2,
        NewEnumerator1 = 3,
        ButtonShape_MAX = 4,
    };
}

