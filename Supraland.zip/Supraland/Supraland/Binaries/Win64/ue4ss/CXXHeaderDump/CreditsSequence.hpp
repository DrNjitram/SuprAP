#ifndef UE4SS_SDK_CreditsSequence_HPP
#define UE4SS_SDK_CreditsSequence_HPP

class USequenceDirector_C : public ULevelSequenceDirector
{

    void disableCinematicCullDistance(class ABP_CinematicCullingHandler_C* Target);
    void enableCinematicCullDistance(class ABP_CinematicCullingHandler_C* Target);
}; // Size: 0x30

#endif
