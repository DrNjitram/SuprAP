#ifndef UE4SS_SDK_CameraShakeStompLess_HPP
#define UE4SS_SDK_CameraShakeStompLess_HPP

class UCameraShakeStompLess_C : public UMatineeCameraShake
{
}; // Size: 0x180

#endif
