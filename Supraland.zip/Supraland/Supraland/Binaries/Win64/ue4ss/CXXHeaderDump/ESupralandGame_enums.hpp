namespace ESupralandGame {
    enum Type {
        NewEnumerator4 = 0,
        NewEnumerator3 = 1,
        NewEnumerator0 = 2,
        NewEnumerator1 = 3,
        NewEnumerator2 = 4,
        ESupralandGame_MAX = 5,
    };
}

