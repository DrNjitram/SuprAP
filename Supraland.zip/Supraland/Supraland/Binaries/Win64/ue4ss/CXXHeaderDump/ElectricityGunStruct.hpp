#ifndef UE4SS_SDK_ElectricityGunStruct_HPP
#define UE4SS_SDK_ElectricityGunStruct_HPP

struct FElectricityGunStruct
{
    class UParticleSystemComponent* particle_12_F330FAB44AF196C6C2AFE89E1481449B;     // 0x0000 (size: 0x8)
    float float_7_7C6574B04DF6BAF22DB4028C910DC122;                                   // 0x0008 (size: 0x4)
    class AActor* TeslaConductor_23_3AD87BC24BE97BB17981B9825D96DAAB;                 // 0x0010 (size: 0x8)
    class UParticleSystemComponent* particle2_22_7F6E3B7D4EF09BB9A7E9E4AC57FC751E;    // 0x0018 (size: 0x8)

}; // Size: 0x20

#endif
