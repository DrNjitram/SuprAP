namespace EInputType {
    enum Type {
        NewEnumerator0 = 0,
        NewEnumerator1 = 1,
        NewEnumerator2 = 2,
        EInputType_MAX = 3,
    };
}

