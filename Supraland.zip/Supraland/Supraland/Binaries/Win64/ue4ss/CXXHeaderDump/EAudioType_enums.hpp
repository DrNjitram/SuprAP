namespace EAudioType {
    enum Type {
        NewEnumerator4 = 0,
        NewEnumerator0 = 1,
        NewEnumerator1 = 2,
        NewEnumerator2 = 3,
        NewEnumerator3 = 4,
        NewEnumerator5 = 5,
        EAudioType_MAX = 6,
    };
}

