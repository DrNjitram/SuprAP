#ifndef UE4SS_SDK_Cupboard_05_HPP
#define UE4SS_SDK_Cupboard_05_HPP

class ACupboard_05_C : public AStaticMeshActor
{
}; // Size: 0x230

#endif
