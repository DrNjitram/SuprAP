#ifndef UE4SS_SDK_BP_MagicianAttackSimple_HPP
#define UE4SS_SDK_BP_MagicianAttackSimple_HPP

class ABP_MagicianAttackSimple_C : public ABP_ProjectileBase_C
{
}; // Size: 0x2F6

#endif
