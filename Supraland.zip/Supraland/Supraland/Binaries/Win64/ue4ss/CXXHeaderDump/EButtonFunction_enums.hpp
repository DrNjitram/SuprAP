namespace EButtonFunction {
    enum Type {
        NewEnumerator0 = 0,
        NewEnumerator1 = 1,
        NewEnumerator6 = 2,
        NewEnumerator2 = 3,
        NewEnumerator3 = 4,
        NewEnumerator5 = 5,
        NewEnumerator7 = 6,
        EButtonFunction_MAX = 7,
    };
}

