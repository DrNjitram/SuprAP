#ifndef UE4SS_SDK_Books_Preset_01_HPP
#define UE4SS_SDK_Books_Preset_01_HPP

class ABooks_Preset_01_C : public AStaticMeshActor
{
}; // Size: 0x230

#endif
