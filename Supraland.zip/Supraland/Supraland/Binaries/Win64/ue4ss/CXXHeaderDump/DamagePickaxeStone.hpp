#ifndef UE4SS_SDK_DamagePickaxeStone_HPP
#define UE4SS_SDK_DamagePickaxeStone_HPP

class UDamagePickaxeStone_C : public UDamagePickaxeWood_C
{
}; // Size: 0x44

#endif
