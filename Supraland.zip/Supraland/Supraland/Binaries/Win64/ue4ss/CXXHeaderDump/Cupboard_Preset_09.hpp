#ifndef UE4SS_SDK_Cupboard_Preset_09_HPP
#define UE4SS_SDK_Cupboard_Preset_09_HPP

class ACupboard_Preset_09_C : public AStaticMeshActor
{
    class UStaticMeshComponent* Cupboard_Preset_09;                                   // 0x0230 (size: 0x8)

}; // Size: 0x238

#endif
