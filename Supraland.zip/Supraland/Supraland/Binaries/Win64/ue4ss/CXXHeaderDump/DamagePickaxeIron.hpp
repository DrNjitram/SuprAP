#ifndef UE4SS_SDK_DamagePickaxeIron_HPP
#define UE4SS_SDK_DamagePickaxeIron_HPP

class UDamagePickaxeIron_C : public UDamagePickaxeWood_C
{
}; // Size: 0x44

#endif
