#ifndef UE4SS_SDK_CameraShakeMagnetRepel_HPP
#define UE4SS_SDK_CameraShakeMagnetRepel_HPP

class UCameraShakeMagnetRepel_C : public UMatineeCameraShake
{
}; // Size: 0x180

#endif
