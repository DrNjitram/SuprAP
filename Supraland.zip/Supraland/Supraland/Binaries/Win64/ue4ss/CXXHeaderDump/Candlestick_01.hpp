#ifndef UE4SS_SDK_Candlestick_01_HPP
#define UE4SS_SDK_Candlestick_01_HPP

class ACandlestick_01_C : public AStaticMeshActor
{
    class UParticleSystemComponent* ParticleSystem2;                                  // 0x0230 (size: 0x8)
    class UParticleSystemComponent* ParticleSystem1;                                  // 0x0238 (size: 0x8)
    class UParticleSystemComponent* ParticleSystem;                                   // 0x0240 (size: 0x8)
    class UPointLightComponent* PointLight;                                           // 0x0248 (size: 0x8)

}; // Size: 0x250

#endif
