#ifndef UE4SS_SDK_CameraShakeDying_HPP
#define UE4SS_SDK_CameraShakeDying_HPP

class UCameraShakeDying_C : public UMatineeCameraShake
{
}; // Size: 0x180

#endif
