#ifndef UE4SS_SDK_Books_Preset_06_HPP
#define UE4SS_SDK_Books_Preset_06_HPP

class ABooks_Preset_06_C : public AStaticMeshActor
{
}; // Size: 0x230

#endif
