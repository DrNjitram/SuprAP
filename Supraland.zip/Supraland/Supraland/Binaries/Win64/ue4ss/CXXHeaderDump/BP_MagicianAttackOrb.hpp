#ifndef UE4SS_SDK_BP_MagicianAttackOrb_HPP
#define UE4SS_SDK_BP_MagicianAttackOrb_HPP

class ABP_MagicianAttackOrb_C : public ABP_ProjectileBase_C
{
}; // Size: 0x2F6

#endif
