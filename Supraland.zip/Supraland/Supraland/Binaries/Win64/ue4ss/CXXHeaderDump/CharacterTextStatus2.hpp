#ifndef UE4SS_SDK_CharacterTextStatus2_HPP
#define UE4SS_SDK_CharacterTextStatus2_HPP

struct FCharacterTextStatus2
{
    TArray<FCharacterDialogue2> Texts_13_1318103C40EF8BA0F199ED8C372344AA;            // 0x0000 (size: 0x10)

}; // Size: 0x10

#endif
