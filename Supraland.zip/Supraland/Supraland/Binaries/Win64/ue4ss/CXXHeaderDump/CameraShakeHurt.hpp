#ifndef UE4SS_SDK_CameraShakeHurt_HPP
#define UE4SS_SDK_CameraShakeHurt_HPP

class UCameraShakeHurt_C : public UMatineeCameraShake
{
}; // Size: 0x180

#endif
