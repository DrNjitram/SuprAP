#ifndef UE4SS_SDK_CameraShakeEarthquakeShort_HPP
#define UE4SS_SDK_CameraShakeEarthquakeShort_HPP

class UCameraShakeEarthquakeShort_C : public UMatineeCameraShake
{
}; // Size: 0x180

#endif
