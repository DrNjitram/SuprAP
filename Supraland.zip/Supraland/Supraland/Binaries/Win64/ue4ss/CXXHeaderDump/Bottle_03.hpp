#ifndef UE4SS_SDK_Bottle_03_HPP
#define UE4SS_SDK_Bottle_03_HPP

class ABottle_03_C : public AStaticMeshActor
{
}; // Size: 0x230

#endif
