#ifndef UE4SS_SDK_FacialAnimation_HPP
#define UE4SS_SDK_FacialAnimation_HPP

class UAudioCurveSourceComponent : public UAudioComponent
{
    FName CurveSourceBindingName;                                                     // 0x0868 (size: 0x8)
    float CurveSyncOffset;                                                            // 0x0870 (size: 0x4)

}; // Size: 0x8A0

#endif
