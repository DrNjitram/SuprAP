#ifndef UE4SS_SDK_ElectricityDamage_HPP
#define UE4SS_SDK_ElectricityDamage_HPP

class UElectricityDamage_C : public UDamageType
{
}; // Size: 0x40

#endif
