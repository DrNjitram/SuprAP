#ifndef UE4SS_SDK_DamagePickaxeWood_HPP
#define UE4SS_SDK_DamagePickaxeWood_HPP

class UDamagePickaxeWood_C : public UDamageType
{
    int32 PickaxeDamage;                                                              // 0x0040 (size: 0x4)

}; // Size: 0x44

#endif
