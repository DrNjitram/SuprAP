#ifndef UE4SS_SDK_BP_KeyInput_AnalogAxis_HPP
#define UE4SS_SDK_BP_KeyInput_AnalogAxis_HPP

class UBP_KeyInput_AnalogAxis_C : public UBP_KeyInput_C
{

    void Key Input Current State(class APlayerController* Controller, float& Axis Value, bool& Down, bool& Just Pressed, bool& Just Released);
}; // Size: 0x68

#endif
