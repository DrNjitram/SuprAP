#ifndef UE4SS_SDK_ChangeClothes_HPP
#define UE4SS_SDK_ChangeClothes_HPP

class IChangeClothes_C : public IInterface
{

    void SelectForceBeam();
    void SelectGun();
    void Equip New Item();
}; // Size: 0x28

#endif
