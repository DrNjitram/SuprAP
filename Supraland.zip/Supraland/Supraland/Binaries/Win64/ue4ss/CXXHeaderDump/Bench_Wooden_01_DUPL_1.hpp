#ifndef UE4SS_SDK_Bench_Wooden_01_DUPL_1_HPP
#define UE4SS_SDK_Bench_Wooden_01_DUPL_1_HPP

class ABench_Wooden_01_C : public AStaticMeshActor
{
}; // Size: 0x230

#endif
