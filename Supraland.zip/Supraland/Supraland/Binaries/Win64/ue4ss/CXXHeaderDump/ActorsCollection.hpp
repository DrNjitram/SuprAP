#ifndef UE4SS_SDK_ActorsCollection_HPP
#define UE4SS_SDK_ActorsCollection_HPP

class AActorsCollection_C : public AActor
{
    class USceneComponent* DefaultSceneRoot;                                          // 0x0220 (size: 0x8)
    TArray<class AActor*> Actors;                                                     // 0x0228 (size: 0x10)

}; // Size: 0x238

#endif
