namespace ETextProgressType {
    enum Type {
        NewEnumerator0 = 0,
        NewEnumerator1 = 1,
        NewEnumerator2 = 2,
        ETextProgressType_MAX = 3,
    };
}

