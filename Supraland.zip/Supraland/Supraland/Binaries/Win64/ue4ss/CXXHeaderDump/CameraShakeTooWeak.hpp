#ifndef UE4SS_SDK_CameraShakeTooWeak_HPP
#define UE4SS_SDK_CameraShakeTooWeak_HPP

class UCameraShakeTooWeak_C : public UMatineeCameraShake
{
}; // Size: 0x180

#endif
