#ifndef UE4SS_SDK_Books_Preset_05_HPP
#define UE4SS_SDK_Books_Preset_05_HPP

class ABooks_Preset_05_C : public AStaticMeshActor
{
}; // Size: 0x230

#endif
