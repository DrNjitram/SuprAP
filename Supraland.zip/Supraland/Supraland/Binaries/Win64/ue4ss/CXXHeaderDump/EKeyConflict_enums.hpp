namespace EKeyConflict {
    enum Type {
        NewEnumerator0 = 0,
        NewEnumerator2 = 1,
        NewEnumerator3 = 2,
        NewEnumerator1 = 3,
        NewEnumerator4 = 4,
        NewEnumerator5 = 5,
        EKeyConflict_MAX = 6,
    };
}

