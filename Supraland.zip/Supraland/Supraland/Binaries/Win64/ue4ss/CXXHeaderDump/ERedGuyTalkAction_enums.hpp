namespace ERedGuyTalkAction {
    enum Type {
        NewEnumerator0 = 0,
        NewEnumerator2 = 1,
        NewEnumerator3 = 2,
        NewEnumerator4 = 3,
        ERedGuyTalkAction_MAX = 4,
    };
}

