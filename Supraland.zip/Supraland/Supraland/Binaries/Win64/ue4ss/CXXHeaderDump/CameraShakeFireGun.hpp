#ifndef UE4SS_SDK_CameraShakeFireGun_HPP
#define UE4SS_SDK_CameraShakeFireGun_HPP

class UCameraShakeFireGun_C : public UMatineeCameraShake
{
}; // Size: 0x180

#endif
