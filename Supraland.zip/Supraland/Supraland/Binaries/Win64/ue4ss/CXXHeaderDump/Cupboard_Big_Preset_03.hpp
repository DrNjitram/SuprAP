#ifndef UE4SS_SDK_Cupboard_Big_Preset_03_HPP
#define UE4SS_SDK_Cupboard_Big_Preset_03_HPP

class ACupboard_Big_Preset_03_C : public AStaticMeshActor
{
    class UStaticMeshComponent* Cupboard_Big_Preset_03;                               // 0x0230 (size: 0x8)

}; // Size: 0x238

#endif
