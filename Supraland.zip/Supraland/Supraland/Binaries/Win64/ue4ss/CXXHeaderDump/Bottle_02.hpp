#ifndef UE4SS_SDK_Bottle_02_HPP
#define UE4SS_SDK_Bottle_02_HPP

class ABottle_02_C : public AStaticMeshActor
{
}; // Size: 0x230

#endif
