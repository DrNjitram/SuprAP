namespace EKeyCombinationDisplay {
    enum Type {
        NewEnumerator0 = 0,
        NewEnumerator1 = 1,
        NewEnumerator2 = 2,
        EKeyCombinationDisplay_MAX = 3,
    };
}

