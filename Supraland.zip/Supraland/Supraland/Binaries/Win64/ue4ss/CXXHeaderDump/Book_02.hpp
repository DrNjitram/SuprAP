#ifndef UE4SS_SDK_Book_02_HPP
#define UE4SS_SDK_Book_02_HPP

class ABook_02_C : public AStaticMeshActor
{
}; // Size: 0x230

#endif
