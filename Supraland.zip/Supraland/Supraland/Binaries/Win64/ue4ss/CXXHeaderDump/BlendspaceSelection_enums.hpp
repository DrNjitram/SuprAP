namespace BlendspaceSelection {
    enum Type {
        NewEnumerator0 = 0,
        NewEnumerator6 = 1,
        NewEnumerator1 = 2,
        NewEnumerator2 = 3,
        NewEnumerator3 = 4,
        NewEnumerator4 = 5,
        NewEnumerator5 = 6,
        NewEnumerator7 = 7,
        NewEnumerator8 = 8,
        NewEnumerator9 = 9,
        NewEnumerator10 = 10,
        BlendspaceSelection_MAX = 11,
    };
}

