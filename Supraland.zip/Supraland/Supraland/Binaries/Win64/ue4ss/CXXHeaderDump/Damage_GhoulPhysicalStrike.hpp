#ifndef UE4SS_SDK_Damage_GhoulPhysicalStrike_HPP
#define UE4SS_SDK_Damage_GhoulPhysicalStrike_HPP

class UDamage_GhoulPhysicalStrike_C : public UDamageType
{
}; // Size: 0x40

#endif
