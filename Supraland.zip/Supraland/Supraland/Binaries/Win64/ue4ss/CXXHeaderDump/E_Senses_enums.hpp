namespace E_Senses {
    enum Type {
        NewEnumerator5 = 0,
        NewEnumerator0 = 1,
        NewEnumerator1 = 2,
        NewEnumerator2 = 3,
        NewEnumerator4 = 4,
        E_MAX = 5,
    };
}

