#ifndef UE4SS_SDK_EnemyFriendlyFire_HPP
#define UE4SS_SDK_EnemyFriendlyFire_HPP

class UEnemyFriendlyFire_C : public UDamageType
{
}; // Size: 0x40

#endif
