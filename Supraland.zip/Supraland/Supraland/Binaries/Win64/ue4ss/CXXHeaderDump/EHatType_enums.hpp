namespace EHatType {
    enum Type {
        NewEnumerator0 = 0,
        NewEnumerator1 = 1,
        NewEnumerator2 = 2,
        EHatType_MAX = 3,
    };
}

