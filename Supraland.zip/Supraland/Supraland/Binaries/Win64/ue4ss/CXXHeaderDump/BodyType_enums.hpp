namespace BodyType {
    enum Type {
        NewEnumerator0 = 0,
        NewEnumerator1 = 1,
        NewEnumerator2 = 2,
        NewEnumerator4 = 3,
        NewEnumerator3 = 4,
        BodyType_MAX = 5,
    };
}

