#ifndef UE4SS_SDK_CameraShakeEarthquakelong_HPP
#define UE4SS_SDK_CameraShakeEarthquakelong_HPP

class UCameraShakeEarthquakelong_C : public UMatineeCameraShake
{
}; // Size: 0x180

#endif
