#ifndef UE4SS_SDK_ArrayOfActorStruct_HPP
#define UE4SS_SDK_ArrayOfActorStruct_HPP

struct FArrayOfActorStruct
{
    TArray<class AActor*> List_3_AF8C3D384AAA7BF7E4153B93A13BFF35;                    // 0x0000 (size: 0x10)

}; // Size: 0x10

#endif
