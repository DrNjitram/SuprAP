namespace EModifySetting {
    enum Type {
        NewEnumerator0 = 0,
        NewEnumerator1 = 1,
        NewEnumerator2 = 2,
        EModifySetting_MAX = 3,
    };
}

