namespace DivideByZeroResult {
    enum Type {
        NewEnumerator0 = 0,
        NewEnumerator1 = 1,
        NewEnumerator2 = 2,
        DivideByZeroResult_MAX = 3,
    };
}

