namespace BuoyancyShape {
    enum Type {
        NewEnumerator0 = 0,
        NewEnumerator1 = 1,
        NewEnumerator2 = 2,
        BuoyancyShape_MAX = 3,
    };
}

