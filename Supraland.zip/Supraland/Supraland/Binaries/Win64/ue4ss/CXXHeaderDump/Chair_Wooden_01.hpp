#ifndef UE4SS_SDK_Chair_Wooden_01_HPP
#define UE4SS_SDK_Chair_Wooden_01_HPP

class AChair_Wooden_01_C : public AStaticMeshActor
{
}; // Size: 0x230

#endif
