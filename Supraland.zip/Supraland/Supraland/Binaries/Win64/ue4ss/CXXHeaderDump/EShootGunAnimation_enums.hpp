namespace EShootGunAnimation {
    enum Type {
        NewEnumerator0 = 0,
        NewEnumerator1 = 1,
        EShootGunAnimation_MAX = 2,
    };
}

