#ifndef UE4SS_SDK_BPI_RegisterKeyBinding_HPP
#define UE4SS_SDK_BPI_RegisterKeyBinding_HPP

class IBPI_RegisterKeyBinding_C : public IInterface
{

    void Key Pressed(FSKeyInput New Keybinding, bool& -);
}; // Size: 0x28

#endif
