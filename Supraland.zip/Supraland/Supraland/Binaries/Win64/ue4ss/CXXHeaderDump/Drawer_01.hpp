#ifndef UE4SS_SDK_Drawer_01_HPP
#define UE4SS_SDK_Drawer_01_HPP

class ADrawer_01_C : public AStaticMeshActor
{
}; // Size: 0x230

#endif
