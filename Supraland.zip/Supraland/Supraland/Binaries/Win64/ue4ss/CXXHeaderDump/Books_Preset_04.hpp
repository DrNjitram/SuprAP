#ifndef UE4SS_SDK_Books_Preset_04_HPP
#define UE4SS_SDK_Books_Preset_04_HPP

class ABooks_Preset_04_C : public AStaticMeshActor
{
}; // Size: 0x230

#endif
