#ifndef UE4SS_SDK_CameraShakeSword_HPP
#define UE4SS_SDK_CameraShakeSword_HPP

class UCameraShakeSword_C : public UMatineeCameraShake
{
}; // Size: 0x180

#endif
