#ifndef UE4SS_SDK_CactusDamage_HPP
#define UE4SS_SDK_CactusDamage_HPP

class UCactusDamage_C : public UDamageType
{
}; // Size: 0x40

#endif
