#ifndef UE4SS_SDK_CameraShakeHurtMuch_HPP
#define UE4SS_SDK_CameraShakeHurtMuch_HPP

class UCameraShakeHurtMuch_C : public UMatineeCameraShake
{
}; // Size: 0x180

#endif
