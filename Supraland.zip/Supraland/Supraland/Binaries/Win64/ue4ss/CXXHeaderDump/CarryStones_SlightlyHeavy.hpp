#ifndef UE4SS_SDK_CarryStones_SlightlyHeavy_HPP
#define UE4SS_SDK_CarryStones_SlightlyHeavy_HPP

class ACarryStones_SlightlyHeavy_C : public ACarryStones_C
{
}; // Size: 0x2AF

#endif
