#ifndef UE4SS_SDK_DamagePickaxeDiamond_HPP
#define UE4SS_SDK_DamagePickaxeDiamond_HPP

class UDamagePickaxeDiamond_C : public UDamagePickaxeWood_C
{
}; // Size: 0x44

#endif
