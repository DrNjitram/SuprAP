#ifndef UE4SS_SDK_CameraShakeFireGunLow_HPP
#define UE4SS_SDK_CameraShakeFireGunLow_HPP

class UCameraShakeFireGunLow_C : public UMatineeCameraShake
{
}; // Size: 0x180

#endif
